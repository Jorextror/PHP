<footer>
    <hr/>
    &copy; <?= date('Y')?>
</footer>

</body>
</html>