<!-- ----- 8 ---- -->
<h2> <?=$nota->getNom()?> </h2>
<h3> <?=$nota->getTitol()?> </h3>
<h3> <?=$nota->getDescripcio()?> </h3>