<!-- La vista és epecífica per cada acció -->
<!-- ---- 6 vista de nota ----- -->
<h1><?=$totesLesNotes?></h1>



