<!-- La vista és epecífica per cada acció -->
<h1><?=$totsElsUsuaris?></h1>
