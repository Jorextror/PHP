<form action="">
Nom: <input type="text">
Cognoms:<input type="text">

</form>