<?php
session_start();
$_SESSION["filtre"]=0;
header("Location: index.php");
?>