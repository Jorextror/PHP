<link rel="stylesheet" href="css/styles.css">
<footer class="footer">
    <hr/>
    &copy; <?= date('Y')?>
</footer>

</body>
</html>