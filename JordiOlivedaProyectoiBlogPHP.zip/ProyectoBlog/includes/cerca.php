<h3>Cerca</h3>
<form action="carcaBD.php" method="post">
    <input type="text" name="cerca" id="carca"  require>
    <input type="submit" value="Cerca">
</form>