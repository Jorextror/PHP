<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
</head>
<body>
<?php
    session_start();
    include 'includes/header.php';
    include 'includes/menu.php';
?>
    <h1>About ...</h1>
    <h3>perniles</h3>
    <p>Más de 3.500 clientes del canal alimentario nos avalan como uno de los grupos líderes en el sector porcino del país, desde la cría de los cerdos hasta la comercialización y exportación del producto final. 
        Las empresas del Grupo d'Avinyó somos especialistas en la producción de carne de cerdo, elaborados y embutidos. Cuidamos todos los procesos y detalles para ofrecer un producto gourmet.
        Además, mantenemos un estrecho vínculo de atención y confianza con nuestros clientes gracias al esfuerzo diario de un equipo de personas comprometidas con su trabajo.</p>
        
    <?php include 'includes/footer.php';?>
</body>
</html>