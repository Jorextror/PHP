<?php
echo "<p>Copyright &copy; 1999-" . date("Y") . " jorextror.com</p>";
?>