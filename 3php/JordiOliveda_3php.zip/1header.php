<?php
/*Fes una plantilla amb un header, footer, i hi haurà un enllaç a cada exercici. 
Utilitza el més adient:  include, require ...*/
echo "<p>PHP-EX-03										M7-UF1</p>";
?>