<?php
$arr1 = array ('c1' => 'Vermell', 'c2' => 'Verd', 'c3' => 'Blanc', 'c4' => 'Negre');
$arr2 = array ("c2", "c4");
foreach ($arr2 as $value) {
    echo $arr1[$value],"&nbsp;";
}
?>