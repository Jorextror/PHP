
   <?php
        include '1header.php';
   ?>

    <div>
        <hr/>
        <h2>Pàgina d'inici </h2>
        <p>Text de prova</p>
    </div>


    <?php
        include '1footer.php';
    ?>